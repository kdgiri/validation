'use strict';

/**
 * @ngdoc directive
 * @name validationApp.directive:name
 * @description
 * # name
 */
 /*
angular.module('validationApp')
  .component('name',  {
    
      bindings: {
      	nameValidation: '='
      }
   
  });

*/
var example = {
  bindings: {
    
    name: '='
  },

  template: '<div>Name: {{$ctrl.name}}</div><br><div><input id="id1" ng-model="$ctrl.name" ng-change="$ctrl.nameCtrl($ctrl.name)"></div>',

    controller: function ($element) {
    	this.nameCtrl=function(nam)
    	{
    		console.log($element);
    		console.log(nam);;
    		if(nam.length==0)
    		{
    			alert('Name is too short');
    		}
    	}
    		
		
  }
};
angular.module('validationApp')
  .component('name',example)
  .directive('replace', function() {
  return {
    require: 'ngModel',
    scope: {
      regex: '@replace',
      with: '@with'
    }, 
    link: function(scope, element, attrs, model) {
      model.$parsers.push(function(val) {
        if (!val) { return; }
        var regex = new RegExp(scope.regex);
        var replaced = val.replace(regex, scope.with); 
        if (replaced !== val) {
          model.$setViewValue(replaced);
          model.$render();
        }         
        return replaced;         
      });
    }
  };
})