'use strict';

/**
 * @ngdoc function
 * @name validationApp.controller:AboutCtrl
 * @description
 * # AboutCtrl
 * Controller of the validationApp
 */
angular.module('validationApp')
  .controller('AboutCtrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
